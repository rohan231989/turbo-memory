(() => {
  const menuButton = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuButton && navLinks) {
    menuButton.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(isOpen));
      menuButton.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
    });
    navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      navLinks.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
      menuButton.setAttribute("aria-label", "Open navigation menu");
    }));
  }

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  // No messages are sent from this static demo. This opens a pre-filled email draft
  // so the customer can review and send it. Replace the address before launch.
  const form = document.getElementById("quote-form");
  const status = document.getElementById("form-status");
  const BUSINESS_EMAIL = "REPLACE-WITH-YOUR-BUSINESS-EMAIL@example.com";

  if (form && status) {
    form.addEventListener("submit", event => {
      event.preventDefault();
      if (!form.reportValidity()) return;

      if (BUSINESS_EMAIL.startsWith("REPLACE-WITH")) {
        status.textContent = "Demo form only: no request has been sent. Add your business email in script.js or connect a form service before publishing.";
        status.scrollIntoView({ behavior: "smooth", block: "nearest" });
        return;
      }

      const data = new FormData(form);
      const lines = [
        "New lawn-care quote request",
        `Name: ${data.get("name")}`,
        `Email: ${data.get("email")}`,
        `Phone: ${data.get("phone") || "Not provided"}`,
        `Property address / postal code: ${data.get("address")}`,
        `Service: ${data.get("service")}`,
        `Approximate lawn size: ${data.get("size") || "Not provided"}`,
        `Preferred frequency: ${data.get("frequency") || "Not provided"}`,
        `Notes: ${data.get("notes") || "None"}`
      ];
      status.textContent = "Your email app should open with the request prepared. Please review and send it to complete your request.";
      window.location.href = `mailto:${BUSINESS_EMAIL}?subject=${encodeURIComponent("Lawn Care Quote Request")}&body=${encodeURIComponent(lines.join("\n"))}`;
    });
  }
})();
