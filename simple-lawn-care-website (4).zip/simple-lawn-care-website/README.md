# Simple Lawn Care Services website

A responsive static website for Simple Lawn Care Services serving Hamilton, Burlington, and nearby Ontario communities. Built with plain HTML, CSS, and JavaScript so it can be hosted free on GitHub Pages.

## Files

- `index.html` — page content, SEO metadata, social sharing metadata, and local business structured data
- `styles.css` — responsive layout, colours, typography, and mobile styles
- `script.js` — mobile navigation, current year, and quote form validation/demo behavior

## Before publishing

1. Replace `REPLACE-WITH-YOUR-BUSINESS-EMAIL@example.com` in `script.js` with the business email you want quote requests sent to. With a real email configured, the form opens the visitor's email app with a pre-filled draft; the visitor must press Send. This is not a server-side form and cannot guarantee delivery.
2. Consider replacing external Unsplash image URLs with photos you own or have licensed. External images and Google Fonts require internet access.
3. Add a real business phone number only if you want it displayed. No phone number, street address, reviews, certifications, insurance claims, or years of experience have been invented here.
4. Verify service coverage and wording before launch. Snow removal is deliberately not presented as an active service.
5. Update the title, description, and structured data if the business offering changes. Add a canonical URL only after your domain is chosen.

## Preview locally

Open `index.html` in a browser. For a local web server, run this from the project folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages

1. Create a GitHub repository named `simple-lawn-care-website` (or use the intended existing website repository).
2. Upload the contents of this folder to the repository root. Make sure `index.html`, `styles.css`, `script.js`, and `README.md` are at the top level.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/(root)` folder, then click **Save**.
6. Wait for the Pages deployment to finish. GitHub will show the published URL under **Settings → Pages**, typically `https://YOUR-USERNAME.github.io/simple-lawn-care-website/`. Use only the exact URL GitHub displays.
7. After later commits to the selected branch, GitHub Pages redeploys the site.

If the Pages section offers a workflow-based deployment instead, use GitHub's current Pages setup guidance and follow the workflow displayed for the repository. The GitHub integration used to prepare these files did not expose a Pages-enablement action.

## Quote form options

### Simplest no-cost demo
Set `BUSINESS_EMAIL` in `script.js` to a real business email. The visitor's email app opens with a prepared message, but the visitor must send it. If the visitor has no configured email app, this may not work smoothly.

### More reliable hosted form
Connect a form provider such as Formspree or another service that supplies a form endpoint. Follow its current setup instructions, then update the form submission code to send to that endpoint. Review its current free/paid limits, spam protection, and privacy terms before choosing. Do not put secret API keys in front-end JavaScript.

### Custom backend
A serverless function or backend can validate and deliver submissions without relying on the visitor's email app. This may introduce hosting, email-delivery, and maintenance costs. Store credentials only in server-side environment variables.

## Custom domain

1. Buy a domain from a registrar.
2. In **Settings → Pages → Custom domain**, enter the domain and save.
3. Configure the DNS records exactly as GitHub Pages instructs for your domain (usually A/AAAA records for an apex domain, or a CNAME for a subdomain).
4. Enable **Enforce HTTPS** once the certificate option becomes available.
5. Update social sharing image URLs and add a canonical URL using the final HTTPS domain.

## Quality and accessibility notes

- Semantic landmarks and headings, skip link, form labels, keyboard-friendly native controls, visible focus styles, and reduced-motion support are included.
- The quote form validates required fields in the browser but does not transmit data until a real submission method is configured.
- Images use descriptive alt text and lazy loading for below-the-fold content.
- Structured data intentionally excludes unverified contact details, ratings, reviews, opening hours, and street address.
